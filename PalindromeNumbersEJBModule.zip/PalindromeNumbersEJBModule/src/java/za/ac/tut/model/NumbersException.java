package za.ac.tut.model;

/**
 *
 * @author MemaniV
 */
public class NumbersException extends javax.ejb.EJBException {
    public NumbersException(String errMsg){
        super(errMsg);
    }
    
}


